// swift-tools-version: 6.0
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "SelectionViewKit",
    platforms: [
        .iOS(.v16),
        .macOS(.v12)
    ],
    products: [
        .library(
            name: "SelectionViewKit",
            targets: ["SelectionViewKit"]),
    ],
    dependencies: [],
    targets: [
        .target(
            name: "SelectionViewKit",
            dependencies: [],
            path: "Sources/SelectionViewKit"),
        .testTarget(
            name: "SelectionViewKitTests",
            dependencies: ["SelectionViewKit"],
            path: "Tests/SelectionViewKitTests"),
        .testTarget(
            name: "SelectionViewKitUITests",
            dependencies: ["SelectionViewKit"],
            path: "Tests/SelectionViewKitUITests")
    ]
)
