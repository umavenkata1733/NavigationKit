// The Swift Programming Language
// https://docs.swift.org/swift-book
// Sources/DentalBenefitsKit/Models/DentalBenefitsData.swift
import Foundation

public struct DentalBenefitsData {
    public let title: String
    public let subtitle: String
    public let supportText: String
    
    public init(
        title: String = "Learn About Dental Benefits",
        subtitle: String = "Your plan may offer dental benefits.",
        supportText: String = "Visit Support Center to find contact information."
    ) {
        self.title = title
        self.subtitle = subtitle
        self.supportText = supportText
    }
}

//Sources/DentalBenefitsKit/Protocol/DentalBenefitsDelegate.swift
import Foundation

public protocol DentalBenefitsDelegate: AnyObject {
    func didTapLearnMore()
    func didTapBack()
}

// Sources/DentalBenefitsKit/Views/DentalBenefitsView.swift
import SwiftUI

public struct DentalBenefitsView: View {
    private let data: DentalBenefitsData
    private weak var delegate: DentalBenefitsDelegate?
    
    public init(
        data: DentalBenefitsData = DentalBenefitsData(),
        delegate: DentalBenefitsDelegate? = nil
    ) {
        self.data = data
        self.delegate = delegate
    }
    
    public var body: some View {
        Button(action: {
            delegate?.didTapLearnMore()
        }) {
            HStack(alignment: .center, spacing: 16) {
                // Dental Icon
                Image(systemName: "tooth")
                    .font(.title2)
                    .foregroundColor(.blue)
                
                // Content
                VStack(alignment: .leading, spacing: 4) {
                    Text(data.title)
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Text(data.subtitle)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text(data.supportText)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                // Chevron
                Image(systemName: "chevron.right")
                    .font(.body)
                    .foregroundColor(.blue)
            }
            .padding()
            .background(Color(.systemBrown))
            .cornerRadius(12)
            .shadow(radius: 1)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// Sources/DentalBenefitsKit/Views/DentalBenefitsContainerView.swift
import SwiftUI

public struct DentalBenefitsContainerView: View {
    @StateObject private var viewModel: DentalBenefitsViewModel
    
    public init(
        data: DentalBenefitsData = DentalBenefitsData(),
        delegate: DentalBenefitsDelegate? = nil
    ) {
        _viewModel = StateObject(wrappedValue: DentalBenefitsViewModel(
            data: data,
            delegate: delegate
        ))
    }
    
    public var body: some View {
        DentalBenefitsView(
            data: viewModel.data,
            delegate: viewModel.delegate
        )
    }
}

// Sources/DentalBenefitsKit/ViewModels/DentalBenefitsViewModel.swift
import SwiftUI

@MainActor
final class DentalBenefitsViewModel: ObservableObject {
    @Published var data: DentalBenefitsData
    weak var delegate: DentalBenefitsDelegate?
    
    init(
        data: DentalBenefitsData,
        delegate: DentalBenefitsDelegate?
    ) {
        self.data = data
        self.delegate = delegate
    }
}
