// The Swift Programming Language
// https://docs.swift.org/swift-book


// Sources/MentalHealthKit/Models/MentalHealthData.swift
import Foundation

public struct MentalHealthData {
    public let title: String
    public let subtitle: String
    public let actionText: String
    
    public init(
        title: String = "Get access to mental health and wellness support",
        subtitle: String = "Explore our wellness resources to live a healthier tomorrow.",
        actionText: String = "Learn about Health and Wellness resources"
    ) {
        self.title = title
        self.subtitle = subtitle
        self.actionText = actionText
    }
}

// Sources/MentalHealthKit/Protocol/MentalHealthDelegate.swift
import Foundation

public protocol MentalHealthDelegate: AnyObject {
    func didTapLearnMore()
}

// Sources/MentalHealthKit/Views/MeditationPersonView.swift
import SwiftUI

struct MeditationPersonView: View {
    var body: some View {
        GeometryReader { geometry in
            let width = min(geometry.size.width, geometry.size.height)
            let height = width * 1.2
            
            ZStack {
                // Background light blue circle
                Circle()
                    .fill(Color.blue.opacity(0.1))
                    .frame(width: width * 1.2)
                    .offset(y: height * 0.1)
                
                // Person
                VStack(spacing: 0) {
                    // Head
                    Circle()
                        .fill(Color.black)
                        .frame(width: width * 0.2)
                    
                    // Body
                    Rectangle()
                        .fill(Color.orange)
                        .frame(width: width * 0.6, height: height * 0.4)
                    
                    // Legs crossed
                    ZStack {
                        Path { path in
                            path.move(to: CGPoint(x: width * 0.2, y: 0))
                            path.addQuadCurve(
                                to: CGPoint(x: width * 0.8, y: 0),
                                control: CGPoint(x: width * 0.5, y: height * 0.2)
                            )
                        }
                        .stroke(Color.orange, lineWidth: width * 0.15)
                    }
                    .frame(height: height * 0.2)
                }
            }
        }
    }
}

// Sources/MentalHealthKit/Views/MentalHealthView.swift
import SwiftUI

public struct MentalHealthView: View {
    private let data: MentalHealthData
    private weak var delegate: MentalHealthDelegate?
    
    public init(
        data: MentalHealthData = MentalHealthData(),
        delegate: MentalHealthDelegate? = nil
    ) {
        self.data = data
        self.delegate = delegate
    }
    
    public var body: some View {
        Button(action: {
            delegate?.didTapLearnMore()
        }) {
            HStack(alignment: .center, spacing: 20) {
                // Content
                VStack(alignment: .leading, spacing: 8) {
                    Text(data.title)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                    
                    Text(data.subtitle)
                        .font(.system(size: 15))
                        .foregroundColor(.secondary)
                    
                    Text(data.actionText)
                        .font(.system(size: 17))
                        .foregroundColor(.blue)
                }
                
                // Meditation Person
                MeditationPersonView()
                    .frame(width: 80, height: 80)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.systemBackground))
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.05), radius: 1, x: 0, y: 1)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// Sources/MentalHealthKit/Views/MentalHealthContainerView.swift
import SwiftUI

public struct MentalHealthContainerView: View {
    @StateObject private var viewModel: MentalHealthViewModel
    
    public init(
        data: MentalHealthData = MentalHealthData(),
        delegate: MentalHealthDelegate? = nil
    ) {
        _viewModel = StateObject(wrappedValue: MentalHealthViewModel(
            data: data,
            delegate: delegate
        ))
    }
    
    public var body: some View {
        MentalHealthView(
            data: viewModel.data,
            delegate: viewModel.delegate
        )
    }
}

// Sources/MentalHealthKit/ViewModels/MentalHealthViewModel.swift
import SwiftUI

@MainActor
final class MentalHealthViewModel: ObservableObject {
    @Published var data: MentalHealthData
    weak var delegate: MentalHealthDelegate?
    
    init(
        data: MentalHealthData,
        delegate: MentalHealthDelegate?
    ) {
        self.data = data
        self.delegate = delegate
    }
}
