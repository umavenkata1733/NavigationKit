// The Swift Programming Language
// https://docs.swift.org/swift-book


// Sources/CostServicesKit/Actions/CostServiceAction.swift
import Foundation

public enum CostServiceAction {
    case medicalEstimator
    case drugEstimator
    case idCard
    case showMore
    
    public var analyticsName: String {
        switch self {
        case .medicalEstimator: return "medical_estimator_tap"
        case .drugEstimator: return "drug_estimator_tap"
        case .idCard: return "id_card_tap"
        case .showMore: return "show_more_tap"
        }
    }
}

// Sources/CostServicesKit/Models/CostModels.swift
import Foundation

public struct CostServiceSection: Identifiable {
    public let id = UUID()
    public let type: SectionType
    public let cells: [CostServiceCell]
    
    public init(type: SectionType, cells: [CostServiceCell]) {
        self.type = type
        self.cells = cells
    }
    
    public enum SectionType {
        case costEstimates
        case idCard
    }
}

public struct CostServiceCell: Identifiable {
    public let id = UUID()
    public let icon: String
    public let title: String
    public let subtitle: String
    public let action: CostServiceAction
    
    public init(
        icon: String,
        title: String,
        subtitle: String,
        action: CostServiceAction
    ) {
        self.icon = icon
        self.title = title
        self.subtitle = subtitle
        self.action = action
    }
}

// Sources/CostServicesKit/ViewModels/CostServicesViewModel.swift
import SwiftUI

@MainActor
public class CostServicesViewModel: ObservableObject {
    @Published private(set) var sections: [CostServiceSection]
    @Published public var isEstimatesExpanded = false
    
    public let onAction: (CostServiceAction) -> Void
    
    public init(sections: [CostServiceSection], onAction: @escaping (CostServiceAction) -> Void) {
        self.sections = sections
        self.onAction = onAction
    }
    
    func handleAction(_ action: CostServiceAction) {
        if action == .showMore {
            isEstimatesExpanded.toggle()
        }
        onAction(action)
    }
}

// Sources/CostServicesKit/Views/Components/CostServiceCellView.swift
import SwiftUI

struct CostServiceCellView: View {
    let cell: CostServiceCell
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 16) {
                ZStack {
                    Circle()
                        .fill(Color.blue.opacity(0.1))
                        .frame(width: 40, height: 40)
                    
                    Image(systemName: cell.icon)
                        .font(.system(size: 20))
                        .foregroundColor(.blue)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(cell.title)
                        .font(.system(size: 17))
                        .foregroundColor(.primary)
                    
                    Text(cell.subtitle)
                        .font(.system(size: 15))
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.system(size: 14))
                    .foregroundColor(.blue)
            }
            .padding(.vertical, 12)
            .padding(.horizontal, 16)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// Sources/CostServicesKit/Views/CostServicesView.swift
import SwiftUI

public struct CostServicesView: View {
    @StateObject private var viewModel: CostServicesViewModel
    
    public init(viewModel: CostServicesViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }
    
    public var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            ForEach(viewModel.sections) { section in
                switch section.type {
                case .costEstimates:
                    costEstimatesSection(section)
                case .idCard:
                    idCardSection(section)
                }
            }
        }
    }
    
    private func costEstimatesSection(_ section: CostServiceSection) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Find More Cost Estimates")
                .font(.system(size: 20, weight: .semibold))
                .padding(.horizontal, 16)
                .padding(.vertical, 16)
            
            Divider().padding(.leading, 16)
            
            ForEach(Array(section.cells.enumerated()), id: \.1.id) { index, cell in
                if index < 2 || viewModel.isEstimatesExpanded {
                    CostServiceCellView(cell: cell) {
                        viewModel.handleAction(cell.action)
                    }
                    
                    if index < (viewModel.isEstimatesExpanded ? section.cells.count - 1 : 1) {
                        Divider().padding(.leading, 72)
                    }
                }
            }
            
            if section.cells.count > 2 && !viewModel.isEstimatesExpanded {
                showMoreButton
            }
        }
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color(.systemGray5), lineWidth: 1)
        )
    }
    
    private func idCardSection(_ section: CostServiceSection) -> some View {
        VStack(spacing: 0) {
            ForEach(section.cells) { cell in
                CostServiceCellView(cell: cell) {
                    viewModel.handleAction(cell.action)
                }
            }
        }
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color(.systemGray5), lineWidth: 1)
        )
    }
    
    private var showMoreButton: some View {
        Button(action: { viewModel.handleAction(.showMore) }) {
            HStack {
                Text("Show More")
                    .font(.system(size: 15))
                Image(systemName: "chevron.down")
                    .font(.system(size: 12))
            }
            .foregroundColor(.blue)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(PlainButtonStyle())
    }
}
