// The Swift Programming Language
// https://docs.swift.org/swift-book
import SwiftUI

struct BenefitSummaryView: View {
    let title: String
    let description: String
    let commonlyUsedServicesTitle: String
    let commonlyUsedServices: [String]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Understand Your Plan section
            VStack(alignment: .leading, spacing: 8) {
                Text(title)
                    .font(.headline)
                
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray, lineWidth: 1)
            )
            
            // Commonly Used Services section
            VStack(alignment: .leading, spacing: 8) {
                Text(commonlyUsedServicesTitle)
                    .font(.headline)
                
                ForEach(commonlyUsedServices, id: \.self) { service in
                    ZStack {
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.blue.opacity(0.2))
                        
                        Text(service)
                            .font(.subheadline)
                            .foregroundColor(.blue)
                            .padding(8)
                    }
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray, lineWidth: 1)
            )
        }
    }
}
