//
//  DentalCareView.swift
//  DemoPro
//
//  Created by Anand on 2/2/25.
//
import SwiftUI
import DentalBenefitsKit

struct DentalCareView: View {
    @StateObject private var viewModel = DentalCareViewModel()
    
    var body: some View {
            VStack {
                DentalBenefitsContainerView(
                    data: DentalBenefitsData(
                        title: "Learn About Dental Benefits",
                        subtitle: "Your plan may offer dental benefits.",
                        supportText: "Visit Support Center to find contact information."
                    ),
                    delegate: viewModel
                )
            }
            .sheet(isPresented: $viewModel.isShowingDetail) {
                DentalDetailView(delegate: viewModel)
            }
        
    }
}

class DentalCareViewModel: ObservableObject, DentalBenefitsDelegate {
    @Published var isShowingDetail = false
    
    // MARK: - DentalBenefitsDelegate Methods
    func didTapLearnMore() {
        isShowingDetail = true
    }
    
    func didTapBack() {
        isShowingDetail = false
    }
}



// Detail View that shows when Learn More is tapped
struct DentalDetailView: View {
    @Environment(\.dismiss) var dismiss
    weak var delegate: DentalBenefitsDelegate?
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Dental Benefits Details")
                    .font(.title)
                    .padding()
                
                // Add your dental benefits details here
                
                Spacer()
            }
            .navigationTitle("Dental Benefits")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Back") {
                        dismiss()
                        delegate?.didTapBack()
                    }
                }
            }
        }
    }
}

// Preview
struct DentalCareView_Previews: PreviewProvider {
    static var previews: some View {
        DentalCareView()
    }
}
