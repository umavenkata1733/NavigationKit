// Sources/DentalBenefitsKit/Views/DentalToothIcon.swift



// Sources/DentalBenefitsKit/Models/DentalBenefitsData.swift
import Foundation

public struct DentalBenefitsData {
    public let title: String
    public let subtitle: String
    public let supportText: String
    
    public init(
        title: String = "Learn About Dental Benefits",
        subtitle: String = "Your plan may offer dental benefits.",
        supportText: String = "Visit Support Center to find contact information."
    ) {
        self.title = title
        self.subtitle = subtitle
        self.supportText = supportText
    }
}

// Sources/DentalBenefitsKit/Protocol/DentalBenefitsDelegate.swift
import Foundation

public protocol DentalBenefitsDelegate: AnyObject {
    func didTapLearnMore()
    func didTapBack()
}

// Sources/DentalBenefitsKit/Views/DentalToothIcon.swift
import SwiftUI

struct DentalToothIcon: View {
    var body: some View {
        GeometryReader { geometry in
            let size = min(geometry.size.width, geometry.size.height)
            Path { path in
                // Top of tooth
                path.move(to: CGPoint(x: size * 0.3, y: size * 0.2))
                path.addCurve(
                    to: CGPoint(x: size * 0.7, y: size * 0.2),
                    control1: CGPoint(x: size * 0.4, y: size * 0.1),
                    control2: CGPoint(x: size * 0.6, y: size * 0.1)
                )
                
                // Right side
                path.addCurve(
                    to: CGPoint(x: size * 0.8, y: size * 0.8),
                    control1: CGPoint(x: size * 0.8, y: size * 0.4),
                    control2: CGPoint(x: size * 0.8, y: size * 0.6)
                )
                
                // Bottom curve
                path.addCurve(
                    to: CGPoint(x: size * 0.2, y: size * 0.8),
                    control1: CGPoint(x: size * 0.6, y: size * 0.9),
                    control2: CGPoint(x: size * 0.4, y: size * 0.9)
                )
                
                // Left side
                path.addCurve(
                    to: CGPoint(x: size * 0.3, y: size * 0.2),
                    control1: CGPoint(x: size * 0.2, y: size * 0.6),
                    control2: CGPoint(x: size * 0.2, y: size * 0.4)
                )
            }
            .stroke(Color.blue, lineWidth: size * 0.08)
        }
    }
}

// Sources/DentalBenefitsKit/Views/DentalBenefitsView.swift
import SwiftUI

public struct DentalBenefitsView: View {
    private let data: DentalBenefitsData
    private weak var delegate: DentalBenefitsDelegate?
    
    public init(
        data: DentalBenefitsData = DentalBenefitsData(),
        delegate: DentalBenefitsDelegate? = nil
    ) {
        self.data = data
        self.delegate = delegate
    }
    
    public var body: some View {
        Button(action: {
            delegate?.didTapLearnMore()
        }) {
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .center, spacing: 16) {
                    // Dental Icon with Circle Background
                    ZStack {
                        Circle()
                            .fill(Color.blue.opacity(0.1))
                            .frame(width: 40, height: 40)
                        
                        DentalToothIcon()
                            .frame(width: 24, height: 24)
                            .foregroundColor(.blue)
                    }
                    
                    // Title
                    Text(data.title)
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    // Chevron
                    Image(systemName: "chevron.right")
                        .font(.body)
                        .foregroundColor(.blue)
                }
                
                // Subtitle and Support Text
                VStack(alignment: .leading, spacing: 4) {
                    Text(data.subtitle)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text(data.supportText)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .padding(.leading, 56) // Width of icon (40) + spacing (16)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color(.systemBackground))
            .cornerRadius(12)
            .shadow(radius: 1)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// Sources/DentalBenefitsKit/Views/DentalBenefitsContainerView.swift
import SwiftUI

public struct DentalBenefitsContainerView: View {
    @StateObject private var viewModel: DentalBenefitsViewModel
    
    public init(
        data: DentalBenefitsData = DentalBenefitsData(),
        delegate: DentalBenefitsDelegate? = nil
    ) {
        _viewModel = StateObject(wrappedValue: DentalBenefitsViewModel(
            data: data,
            delegate: delegate
        ))
    }
    
    public var body: some View {
        DentalBenefitsView(
            data: viewModel.data,
            delegate: viewModel.delegate
        )
    }
}

// Sources/DentalBenefitsKit/ViewModels/DentalBenefitsViewModel.swift
import SwiftUI

@MainActor
final class DentalBenefitsViewModel: ObservableObject {
    @Published var data: DentalBenefitsData
    weak var delegate: DentalBenefitsDelegate?
    
    init(
        data: DentalBenefitsData,
        delegate: DentalBenefitsDelegate?
    ) {
        self.data = data
        self.delegate = delegate
    }
}
