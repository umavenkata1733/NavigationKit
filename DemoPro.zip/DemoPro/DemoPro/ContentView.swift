//import SwiftUI
//
//// Reusable Card Style Modifier
//struct CardStyle: ViewModifier {
//    func body(content: Content) -> some View {
//        content
//            .padding(.horizontal, 16)
//            .padding(.vertical, 16)
//            .background(Color(.systemBackground))
//            .cornerRadius(8)
//            .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 1)
//    }
//}
//
//// Extension to make the modifier easier to use
//extension View {
//    func cardStyle() -> some View {
//        modifier(CardStyle())
//    }
//}
//
//struct SelectionView<T: Identifiable & Hashable>: View {
//    let title: String
//    let items: [T]
//    let displayText: (T) -> String
//    @Binding var selectedItem: T?
//    
//    var displayString: String {
//        if let selected = selectedItem {
//            return displayText(selected)
//        } else {
//            return items.map { displayText($0) }.joined(separator: " / ")
//        }
//    }
//    
//    var body: some View {
//        NavigationLink(destination: SelectionListView(
//            title: title,
//            items: items,
//            displayText: displayText,
//            selectedItem: $selectedItem
//        )) {
//            VStack(alignment: .leading) {
//                Text("Viewing information for:")
//                    .font(.system(size: 12))
//                    .foregroundColor(Color(.systemGray))
//                HStack(spacing: 12) {
//                    // Leading circle icon
//                    Circle()
//                        .fill(Color(.systemGray5))
//                        .frame(width: 32, height: 32)
//                        .overlay(
//                            Image(systemName: "person.2.fill")
//                                .foregroundColor(.gray)
//                                .font(.system(size: 14))
//                        )
//                    
//                    // Content
//                    VStack(alignment: .leading, spacing: 2) {
//                        Text(displayString)
//                            .font(.system(size: 15))
//                            .foregroundColor(.primary)
//                            .lineLimit(2)
//                            .fixedSize(horizontal: false, vertical: true)
//                            .multilineTextAlignment(.leading)
//                    }
//                    
//                    Spacer()
//                    
//                    // Trailing chevron
//                    Image(systemName: "chevron.down")
//                        .font(.system(size: 14, weight: .medium))
//                        .foregroundColor(Color(.systemGray3))
//                }
//                .cardStyle()
//            }
//        }
//        .buttonStyle(PlainButtonStyle())
//    }
//}
//
//struct SelectionListView<T: Identifiable & Hashable>: View {
//    let title: String
//    let items: [T]
//    let displayText: (T) -> String
//    @Binding var selectedItem: T?
//    @Environment(\.dismiss) private var dismiss
//    
//    var body: some View {
//        List(items) { item in
//            Button(action: {
//                selectedItem = item
//                dismiss()
//            }) {
//                HStack {
//                    Text(displayText(item))
//                        .font(.system(size: 16))
//                    Spacer()
//                    if item == selectedItem {
//                        Image(systemName: "checkmark")
//                            .foregroundColor(.blue)
//                    }
//                }
//            }
//            .foregroundColor(.primary)
//        }
//        .listStyle(InsetGroupedListStyle())
//        .navigationTitle(title)
//        .navigationBarTitleDisplayMode(.large)
//    }
//}
//
//// Example usage
//struct ExampleView: View {
//    struct Item: Identifiable, Hashable {
//        let id = UUID()
//        let name: String
//    }
//    
//    @State private var selectedItem: Item?
//    let items = [
//        Item(name: "Group RKFM"),
//        Item(name: "Team Alpha"),
//        Item(name: "Division Beta")
//    ]
//    
//    var body: some View {
//        NavigationStack {
//            VStack(alignment: .leading, spacing: 16) {
//                SelectionView(
//                    title: "Select Group",
//                    items: items,
//                    displayText: { $0.name },
//                    selectedItem: $selectedItem
//                )
//                Spacer()
//            }
//            .padding(16)
//            .navigationTitle("Groups")
//        }
//    }
//}
//
//#Preview {
//    ExampleView()
//}
