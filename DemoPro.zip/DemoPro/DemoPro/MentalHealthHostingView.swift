//
//  MentalHealthHostingView.swift
//  DemoPro
//
//  Created by Anand on 2/2/25.
//

import SwiftUI
import MentalHealthKit

class MentalHealthHostingViewModel: ObservableObject, MentalHealthDelegate {
    @Published var isShowingDetail = false
    
    func didTapLearnMore() {
        isShowingDetail = true
    }
}

struct MentalHealthHostingView: View {
    @StateObject private var viewModel = MentalHealthHostingViewModel()
    
    var body: some View {
        MentalHealthContainerView(
            data: MentalHealthData(
                title: "Get access to mental health and wellness support",
                subtitle: "Explore our wellness resources to live a healthier tomorrow.",
                actionText: "Learn about Health and Wellness resources"
            ),
            delegate: viewModel
        )
        .padding()
        .sheet(isPresented: $viewModel.isShowingDetail) {
            ResourcesDetailView()
        }
        Spacer()
    }
}

struct ResourcesDetailView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            List {
                // Add your resources details here
            }
            .navigationTitle("Health & Wellness")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

struct MentalHealthHostingView_Previews: PreviewProvider {
    static var previews: some View {
        MentalHealthHostingView()
    }
}
