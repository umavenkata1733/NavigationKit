import SwiftUI
import SelectionViewKit
import BenefitSummaryView


//struct DemoView: View {
//    // Model
//    struct ExampleItem: Selectable {
//        let id = UUID()
//        let name: String
//        var displayText: String { name }
//    }
//    
//    // Optional delegate
//    class DemoDelegate: SelectionDelegate {
//        func didSelect(item: ExampleItem?) {
//            print("Selected: \(item?.name ?? "none")")
//        }
//    }
//    
//    private let delegate = DemoDelegate()
//    private let items = [
//        ExampleItem(name: "Group RKFM"),
//        ExampleItem(name: "Team Alpha"),
//        ExampleItem(name: "Division Beta")
//    ]
//    
//    var body: some View {
//        VStack(spacing: 20) {
//            // Half screen example
//            SelectionView(
//                title: "Groups",
//                items: items,
//                presentationType: .half,
//                delegate: delegate
//            )
//            
//            // Full screen example
//            SelectionView(
//                title: "Teams",
//                items: items,
//                presentationType: .full,
//                delegate: delegate
//            )
//        }
//        .padding()
//    }
//}



struct ExampleItem: Selectable {
    let id = UUID()
    let name: String
    var displayText: String { name }
}

// Demo/Domain/Delegates/SelectionDelegateImpl.swift

final class SelectionDelegateImpl: SelectionDelegate {
    typealias Item = ExampleItem
    
    func didSelect(item: ExampleItem?) {
        if let item = item {
            print("Selected: \(item.name)")
        }
    }
}

// Demo/Presentation/DemoView.swift

struct DemoView: View {
    private let delegate = SelectionDelegateImpl()
    let benefitSummary = BenefitSummary(
        title: "Benefit Summary",
        
        titleHeader: "Understand Your Plan",
        description: "Review benefits covered under your plan.",
        commonlyUsedServicesTitle: "Commonly Used Services",
        commonlyUsedServices: ["Virtual Care", "Preventive Care", "Emergency Care", "Urgent Care"]
    )

    private let items = [
        ExampleItem(name: "Group RKFM"),
        ExampleItem(name: "Team Alpha"),
        ExampleItem(name: "Division Beta")
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Full screen example
                    SelectionView(
                        title: "Full Screen Demo",
                        items: items,
                        presentationType: .full,
                        delegate: delegate
                    )
                    
                    BenefitSummaryView(benefitSummary: benefitSummary)
                        .frame(maxWidth: .infinity)
                        .background(Color(red: 0.95, green: 0.95, blue: 0.95))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                        )
                    
                    // Just participating and out-of-network
                    ContentView(networks: [.participating, .outOfNetwork])

                    // All three network types
                    //ContentView(networks: [.inNetwork, .participating, .outOfNetwork])

                    // Only in-network and participating
                    //ContentView(networks: [.inNetwork, .participating])
                    DentalCareView()
                    MentalHealthHostingView()
                    CostView()
                    Spacer()
                }
                .padding(.horizontal)
                .navigationTitle("Benefits and Coverage")
            }

        }.background(Color.white)
    }
}

