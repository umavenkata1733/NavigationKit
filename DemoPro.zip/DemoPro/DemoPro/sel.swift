import SwiftUI

// MARK: - Domain Models
struct DeductibleInfo {
    let spent: Double
    let limit: Double
    let type: DeductibleType
    
    var remaining: Double {
        limit - spent
    }
    
    var progress: Double {
        spent / limit
    }
}

enum DeductibleType {
    case individual
    case family
}

enum NetworkType: String, CaseIterable {
    case inNetwork = "In-network"
    case participating = "Participating Provider"
    case outOfNetwork = "Out-of-network"
}

// MARK: - View Models
@MainActor
protocol DeductibleViewModelProtocol: ObservableObject {
    var individualDeductible: DeductibleInfo { get }
    var familyDeductible: DeductibleInfo { get }
    var selectedNetworkType: NetworkType { get set }
    var availableNetworks: [NetworkType] { get }
}

@MainActor
final class DeductibleViewModel: DeductibleViewModelProtocol {
    @Published var individualDeductible: DeductibleInfo
    @Published var familyDeductible: DeductibleInfo
    @Published var selectedNetworkType: NetworkType = .inNetwork {
        didSet {
            updateDeductibles()
        }
    }
    @Published var showingCostInfo = false
    
    let availableNetworks: [NetworkType]
    
    init(
        individualDeductible: DeductibleInfo,
        familyDeductible: DeductibleInfo,
        availableNetworks: [NetworkType]
    ) {
        self.individualDeductible = individualDeductible
        self.familyDeductible = familyDeductible
        self.availableNetworks = availableNetworks
        
        if let firstNetwork = availableNetworks.first {
            self.selectedNetworkType = firstNetwork
        }
    }
    
    private func updateDeductibles() {
        let newData = DeductibleStaticData.getData(for: selectedNetworkType)
        withAnimation {
            self.individualDeductible = newData.individual
            self.familyDeductible = newData.family
        }
    }
}

// MARK: - Circular Progress View
struct CircularProgressView: View {
    let progress: Double
    let strokeWidth: CGFloat
    let color: Color
    let size: CGSize
    
    init(
        progress: Double,
        strokeWidth: CGFloat = 12,
        color: Color = .blue,
        size: CGSize = CGSize(width: 160, height: 120)
    ) {
        self.progress = min(max(progress, 0), 1)
        self.strokeWidth = strokeWidth
        self.color = color
        self.size = size
    }
    
    var body: some View {
        ZStack {
            // Background Arc (3/4 circle)
            Circle()
                .trim(from: 0, to: 0.75)
                .stroke(
                    Color.gray.opacity(0.2),
                    style: StrokeStyle(
                        lineWidth: strokeWidth,
                        lineCap: .round
                    )
                )
                .rotationEffect(.degrees(135))
            
            // Progress Arc
            Circle()
                .trim(from: 0, to: progress * 0.75)
                .stroke(
                    color,
                    style: StrokeStyle(
                        lineWidth: strokeWidth,
                        lineCap: .round
                    )
                )
                .rotationEffect(.degrees(135))
        }
        .frame(width: size.width, height: size.height)
    }
}

// MARK: - Custom Segmented Control
struct CustomSegmentedControl: View {
    @Binding var selection: NetworkType
    let segments: [NetworkType]
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(segments, id: \.self) { segment in
                Button(action: {
                    withAnimation {
                        selection = segment
                    }
                }) {
                    Text(segment.rawValue)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .frame(maxWidth: .infinity)
                        .font(.caption)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(selection == segment ? Color.white : Color.clear)
                        )
                }
                .foregroundColor(selection == segment ? .primary : .secondary)
            }
        }
        .padding(4)
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .padding(.horizontal)
    }
}

// MARK: - Deductible Progress View
struct DeductibleProgressView: View {
    let info: DeductibleInfo
    let icon: String
    let label: String
    
    var body: some View {
        VStack(spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.title3)
                Text(label)
                    .font(.subheadline)
            }
            
            ZStack {
                CircularProgressView(
                    progress: info.progress,
                    strokeWidth: 12,
                    color: info.type == .individual ? .blue : .purple,
                    size: CGSize(width: 160, height: 120)
                )
                
                VStack {
                    Text("$\(Int(info.remaining))")
                        .font(.title2)
                        .fontWeight(.semibold)
                    Text("Remaining")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Text("$\(Int(info.spent)) Spent of $\(Int(info.limit))")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}

// MARK: - DeductibleTrackerView
struct DeductibleTrackerView: View {
    @ObservedObject var viewModel: DeductibleViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Track Your Spending")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.horizontal)
            
            CustomSegmentedControl(
                selection: $viewModel.selectedNetworkType,
                segments: viewModel.availableNetworks
            )
            
            VStack(alignment: .leading, spacing: 16) {
                Text(viewModel.selectedNetworkType.rawValue)
                    .font(.headline)
                VStack(alignment: .leading, spacing: 16) {
                    HStack {
                        Text("Your costs for most services:")
                        Text("Full Cost")
                            .fontWeight(.medium)
                        Button(action: {
                            viewModel.showingCostInfo = true
                        }) {
                            Image(systemName: "info.circle")
                                .foregroundColor(.blue)
                        }
                    }
                    Text("Costs for services vary depending on how deductible and out-of-pocket limits apply.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                   
                }.foregroundColor(.secondary)
                    .frame(maxWidth: .infinity)
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color(.systemBlue))
                            .opacity(0.05)
                    )
                    .padding(.top, 8)


                
                
                Button(action: {}) {
                    HStack {
                        Image(systemName: "person.3.fill")
                        Text("Learn How Family Plans Work")
                    }
                }
                
                VStack(alignment: .leading, spacing: 16) {
                    Text("Deductible Limit \n$3000 Remaining")
                        .font(.headline)
                    
                    Text("Amount you must spend towards the individual deductible limit before you begin paying copay and coinsurance")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    HStack {
                        Text("$500 Remaining $500")
                            .font(.title3)
                            .padding(.top, 8)
                        Spacer()
                        Button(action: {
                            viewModel.showingCostInfo = true
                        }) {
                            Image(systemName: "info.circle")
                                .foregroundColor(.blue)
                        }
                    }.foregroundColor(.secondary)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color(.systemGray5))
                                .opacity(0.5)
                        )
                        .padding(.top, 8)

                    
                    HStack(spacing: 40) {
                        DeductibleProgressView(
                            info: viewModel.individualDeductible,
                            icon: "person",
                            label: "Individual Deductible"
                        )
                        
                        DeductibleProgressView(
                            info: viewModel.familyDeductible,
                            icon: "person.3",
                            label: "Family Deductible"
                        )
                    }
                }.background(Color(.systemBackground))
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(.systemGray5), lineWidth: 1)
                    )
                    .padding(.vertical, 20)
                VStack(alignment: .leading, spacing: 16) {
                    Text("Out-of-Pocket Limit \n$5000 Remaining")
                        .font(.headline)
                    
                    Text("The amount you must spend towards the individual out-of-pocket limit before you begin paying no cost for most services")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    HStack {
                        Text("$500 Remaining $500")
                            .font(.title3)
                            .padding(.top, 8)
                        Spacer()
                        Button(action: {
                            viewModel.showingCostInfo = true
                        }) {
                            Image(systemName: "info.circle")
                                .foregroundColor(.blue)
                        }
                    }.foregroundColor(.secondary)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color(.systemGray5))
                                .opacity(0.5)
                        )
                        .padding(.top, 8)

                    
                    HStack(spacing: 40) {
                        DeductibleProgressView(
                            info: viewModel.individualDeductible,
                            icon: "person",
                            label: "Individual \nOut-of-Pocket"
                        )
                        
                        DeductibleProgressView(
                            info: viewModel.familyDeductible,
                            icon: "person.3",
                            label: "Family \nOut-of-Pocket"
                        )
                    }
                }.background(Color(.systemBackground))
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(.systemGray5), lineWidth: 1)
                    )
                    .padding(.vertical, 20)

            }

        }
        .sheet(isPresented: $viewModel.showingCostInfo) {
            CostInfoSheet()
        }
    }
}

// MARK: - Cost Info Sheet
struct CostInfoSheet: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Cost Information")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Full Cost Explanation")
                            .font(.headline)
                        
                        Text("When you have a deductible, you'll pay the full cost of services until you meet your deductible amount.")
                            .foregroundColor(.secondary)
                        
                        Text("Common Services at Full Cost:")
                            .font(.subheadline)
                            .padding(.top, 8)
                        
                        BulletPoint("Doctor visits")
                        BulletPoint("Lab work")
                        BulletPoint("X-rays and imaging")
                        BulletPoint("Specialist consultations")
                    }
                    .padding(.vertical, 8)
                }
            }
            .navigationTitle("Cost Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

struct BulletPoint: View {
    let text: String
    
    init(_ text: String) {
        self.text = text
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Text("•")
            Text(text)
        }
        .foregroundColor(.secondary)
    }
}

// MARK: - Static Data
struct NetworkDeductibleData {
    let individual: DeductibleInfo
    let family: DeductibleInfo
}

struct DeductibleStaticData {
    static func getData(for networkType: NetworkType) -> NetworkDeductibleData {
        switch networkType {
        case .inNetwork:
            return NetworkDeductibleData(
                individual: DeductibleInfo(spent: 700, limit: 1000, type: .individual),
                family: DeductibleInfo(spent: 2900, limit: 3500, type: .family)
            )
        case .participating:
            return NetworkDeductibleData(
                individual: DeductibleInfo(spent: 500, limit: 2000, type: .individual),
                family: DeductibleInfo(spent: 1500, limit: 4000, type: .family)
            )
        case .outOfNetwork:
            return NetworkDeductibleData(
                individual: DeductibleInfo(spent: 300, limit: 3000, type: .individual),
                family: DeductibleInfo(spent: 1000, limit: 6000, type: .family)
            )
        }
    }
}

// MARK: - Content View
struct ContentView: View {
    @StateObject private var viewModel: DeductibleViewModel
    
    init(networks: [NetworkType]) {
        let initialData = DeductibleStaticData.getData(for: networks[0])
        _viewModel = StateObject(wrappedValue: DeductibleViewModel(
            individualDeductible: initialData.individual,
            familyDeductible: initialData.family,
            availableNetworks: networks
        ))
    }
    
    var body: some View {
        DeductibleTrackerView(viewModel: viewModel)
    }
}

// MARK: - Preview Provider
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(networks: [.participating, .outOfNetwork])
    }
}
