//
//  DemoProApp.swift
//  DemoPro
//
//  Created by Anand on 2/1/25.
//

import SwiftUI

@main
struct DemoProApp: App {
    var body: some Scene {
        WindowGroup {
            DemoView()
        }
    }
}
