//
//  SelectionHeaderView.swift
//  SelectionViewKit
//
//  Created by Anand on 2/1/25.
//

import SwiftUI

struct SelectionHeaderView<Item: Selectable>: View {
    @ObservedObject var viewModel: SelectionViewModel<Item>
    let style: SelectionStyle
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(SelectionConstants.Strings.viewingInfoTitle)
                .foregroundColor(SelectionConstants.Colors.titleColor)
                .font(.title2)
                .fontWeight(.bold)

            HStack(spacing: SelectionConstants.Layout.spacing) {
                Circle()
                    .fill(style.iconBackground)
                    .frame(width: SelectionConstants.Layout.iconSize,
                           height: SelectionConstants.Layout.iconSize)
                    .overlay(
                        Image(systemName: SelectionConstants.SystemImages.personIcon)
                            .foregroundColor(style.iconForeground)
                            .font(.system(size: SelectionConstants.Layout.iconFontSize))
                    )
                
                Text(viewModel.displayString)
                    .font(.system(size: SelectionConstants.Layout.contentFontSize))
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                
                Spacer()
                
                Image(systemName: SelectionConstants.SystemImages.chevronDown)
                    .font(.system(size: SelectionConstants.Layout.iconFontSize))
                    .foregroundColor(SelectionConstants.Colors.chevronColor)
            }
            .padding(SelectionConstants.Layout.padding)
            .background(Color(.systemBackground))
            .cornerRadius(SelectionConstants.Layout.cornerRadius)
            .shadow(color: SelectionConstants.Colors.shadowColor,
                    radius: 2, x: 0, y: 1)
        }
    }
}
